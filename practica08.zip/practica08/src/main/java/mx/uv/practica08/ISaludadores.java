package mx.uv.practica08;

import org.springframework.data.repository.CrudRepository;

public interface ISaludadores extends CrudRepository<Saludadores, Integer>{
    
}
