package mx.uv.practica08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
