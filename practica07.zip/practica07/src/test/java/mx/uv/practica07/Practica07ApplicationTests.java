package mx.uv.practica07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
